package com.weather.projectsky;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectSkyApplicationTests {

    @Test
    void contextLoads() {
    }

}
