package com.weather.projectsky;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectSkyApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjectSkyApplication.class, args);
    }

}
